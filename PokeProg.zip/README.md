# PokeProg
 Pokemon Battle in C
